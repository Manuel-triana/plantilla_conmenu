<ul class="navbar-nav flex-grow-1 justify-content-between">
          <li class="nav-item"><a class="nav-link" href="index.php">
            <svg class="bi" width="24" height="24"><use xlink:href="#aperture"/></svg>
          </a></li>
          <li class="nav-item"><a class="nav-link" href="paciente.php">Paciente</a></li>
          <li class="nav-item"><a class="nav-link" href="drogas.php">Drogas</a></li>
          <li class="nav-item"><a class="nav-link" href="facturar.php">Facturar</a></li>
          <li class="nav-item"><a class="nav-link" href="consulta.php">Consulta</a></li>
            <svg class="bi" width="24" height="24"><use xlink:href="#cart"/></svg>
          </a></li>
        </ul>